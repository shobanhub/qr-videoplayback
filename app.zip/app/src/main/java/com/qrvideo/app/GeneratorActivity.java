package com.qrvideo.app;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.io.File;
import java.io.FileOutputStream;
import java.util.EnumMap;
import java.util.Map;
import android.content.Intent;

/** Workflow 4: make a QR from text or a video link, then share the image. */
public class GeneratorActivity extends AppCompatActivity {
    private EditText input;
    private ImageView img;
    private Bitmap bmp;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = Ui.page(this, "Make QR");
        input = new EditText(this);
        input.setHint("Text or link");
        input.setHintTextColor(Ui.SUB);
        input.setTextColor(Ui.TXT);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setBackgroundResource(R.drawable.bg_btn);
        input.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        String t = getIntent().getStringExtra("text");
        if (t != null) input.setText(t);
        col.addView(input, new LinearLayout.LayoutParams(-1, -2));
        col.addView(Ui.btn(this, "Make QR", true, v -> generate()));
        img = new ImageView(this);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(this, 280), Ui.dp(this, 280));
        p.gravity = Gravity.CENTER_HORIZONTAL;
        p.topMargin = Ui.dp(this, 16);
        col.addView(img, p);
        col.addView(Ui.btn(this, "Share image", false, v -> share()));
        if (t != null) generate();
    }

    private void generate() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) { Ui.toast(this, "Type something first"); return; }
        try {
            Map<EncodeHintType, Object> h = new EnumMap<>(EncodeHintType.class);
            h.put(EncodeHintType.MARGIN, 2);
            h.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
            h.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 768, 768, h);
            int w = m.getWidth(), ht = m.getHeight();
            int[] px = new int[w * ht];
            for (int y = 0; y < ht; y++)
                for (int x = 0; x < w; x++) px[y * w + x] = m.get(x, y) ? 0xFF000000 : 0xFFFFFFFF;
            bmp = Bitmap.createBitmap(px, w, ht, Bitmap.Config.ARGB_8888);
            img.setImageBitmap(bmp);
        } catch (Exception e) {
            Ui.toast(this, "Too long for QR");
        }
    }

    private void share() {
        if (bmp == null) { Ui.toast(this, "Make a QR first"); return; }
        try {
            File dir = new File(getCacheDir(), "qr");
            dir.mkdirs();
            File f = new File(dir, "qr.png");
            try (FileOutputStream o = new FileOutputStream(f)) { bmp.compress(Bitmap.CompressFormat.PNG, 100, o); }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent i = new Intent(Intent.ACTION_SEND).setType("image/png")
                .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Share QR"));
        } catch (Exception e) {
            Ui.toast(this, "Share failed");
        }
    }
}
