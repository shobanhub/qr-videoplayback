package com.qrvideo.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Workflow 1: live camera scan (CameraX + ZXing) and scan-from-gallery. */
public class ScannerActivity extends AppCompatActivity {
    private PreviewView preview;
    private TextView result;
    private LinearLayout actions;
    private Camera camera;
    private boolean torch;
    private String mode, last = "";
    private long lastAt;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final MultiFormatReader reader = new MultiFormatReader();
    private final Map<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);

    private final ActivityResultLauncher<String> camPerm = registerForActivityResult(
        new ActivityResultContracts.RequestPermission(), ok -> {
            if (ok) startCamera(); else Ui.toast(this, "Camera blocked");
        });
    private final ActivityResultLauncher<String> pick = registerForActivityResult(
        new ActivityResultContracts.GetContent(), this::scanImage);

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        mode = getIntent().getStringExtra("mode");
        hints.put(DecodeHintType.POSSIBLE_FORMATS, Collections.singletonList(BarcodeFormat.QR_CODE));
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        reader.setHints(hints);

        LinearLayout col = Ui.page(this, "Scan");
        preview = new PreviewView(this);
        col.addView(preview, new LinearLayout.LayoutParams(-1, Ui.dp(this, 380)));
        result = Ui.text(this, "No scan yet", 15, Ui.SUB);
        col.addView(result);
        actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        col.addView(actions);
        col.addView(Ui.row(this,
            Ui.btn(this, "Flashlight", false, v -> toggleTorch()),
            Ui.btn(this, "Gallery", false, v -> pick.launch("image/*"))));

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera();
        else camPerm.launch(Manifest.permission.CAMERA);
    }

    private void startCamera() {
        final ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(this);
        f.addListener(() -> {
            try {
                ProcessCameraProvider provider = f.get();
                Preview p = new Preview.Builder().build();
                p.setSurfaceProvider(preview.getSurfaceProvider());
                ImageAnalysis ia = new ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                ia.setAnalyzer(exec, this::analyze);
                provider.unbindAll();
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, p, ia);
            } catch (Exception e) {
                Ui.toast(this, "Camera error");
            }
        }, ContextCompat.getMainExecutor(this));
    }

    /** Runs on the background thread, one frame at a time. */
    private void analyze(ImageProxy image) {
        try {
            ImageProxy.PlaneProxy y = image.getPlanes()[0];
            ByteBuffer buf = y.getBuffer();
            byte[] data = new byte[buf.remaining()];
            buf.get(data);
            PlanarYUVLuminanceSource src = new PlanarYUVLuminanceSource(
                data, y.getRowStride(), image.getHeight(), 0, 0, image.getWidth(), image.getHeight(), false);
            final String text = reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(src))).getText();
            runOnUiThread(() -> onCode(text));
        } catch (Exception ignored) {
            // no QR in this frame
        } finally {
            reader.reset();
            image.close();
        }
    }

    private void onCode(final String text) {
        long now = System.currentTimeMillis();
        boolean same = text.equals(last) && now - lastAt < 2500;
        lastAt = now;
        if (same) return;
        last = text;
        Store.add(this, text);
        Ui.buzz(this);
        result.setText(text);
        result.setTextColor(Ui.TXT);
        actions.removeAllViews();
        if (Ui.isVideo(text)) actions.addView(Ui.btn(this, "Play video", true, v ->
            startActivity(new Intent(this, PlayerActivity.class).putExtra("mode", mode).putExtra("url", Ui.url(text)))));
        if (Ui.isUrl(text)) actions.addView(Ui.btn(this, "Open link", false, v -> Ui.openLink(this, text)));
        actions.addView(Ui.btn(this, "Copy", false, v -> Ui.copy(this, text)));
        if ("generator".equals(mode)) actions.addView(Ui.btn(this, "Make QR from this", false, v ->
            startActivity(new Intent(this, GeneratorActivity.class).putExtra("mode", mode).putExtra("text", text))));
    }

    private void toggleTorch() {
        if (camera == null || !camera.getCameraInfo().hasFlashUnit()) { Ui.toast(this, "No flashlight"); return; }
        torch = !torch;
        camera.getCameraControl().enableTorch(torch);
    }

    private void scanImage(Uri uri) {
        if (uri == null) return;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / s > 1600) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            Bitmap bm;
            try (InputStream in = getContentResolver().openInputStream(uri)) { bm = BitmapFactory.decodeStream(in, null, o); }
            int w = bm.getWidth(), h = bm.getHeight();
            int[] px = new int[w * h];
            bm.getPixels(px, 0, w, 0, 0, w, h);
            Result r = new MultiFormatReader().decode(new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(w, h, px))), hints);
            onCode(r.getText());
        } catch (Exception e) {
            Ui.toast(this, "No QR found");
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        exec.shutdown();
    }
}
