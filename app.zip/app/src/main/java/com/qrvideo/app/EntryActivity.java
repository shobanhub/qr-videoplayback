package com.qrvideo.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/** Entry: pick a mode and grant hardware (camera) access. */
public class EntryActivity extends AppCompatActivity {
    private TextView hw;
    private String pending;
    private final ActivityResultLauncher<String> camPerm = registerForActivityResult(
        new ActivityResultContracts.RequestPermission(), ok -> {
            refresh();
            if (pending != null) { open(pending); pending = null; }
        });

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = Ui.page(this, "QR Video Playback");
        col.addView(Ui.text(this, "Choose a mode", 14, Ui.SUB));
        col.addView(Ui.card(this, "QR Viewer", "Scan & play", v -> go("viewer")));
        col.addView(Ui.card(this, "QR Generator", "Full access", v -> go("generator")));
        hw = Ui.text(this, "", 14, Ui.TXT);
        col.addView(hw);
        col.addView(Ui.btn(this, "Allow camera", true, v -> camPerm.launch(Manifest.permission.CAMERA)));
        refresh();
    }

    private boolean granted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void refresh() { hw.setText("Camera: " + (granted() ? "allowed" : "not set")); }

    private void go(String mode) {
        if (granted()) open(mode);
        else { pending = mode; camPerm.launch(Manifest.permission.CAMERA); }
    }

    private void open(String mode) { startActivity(new Intent(this, HomeActivity.class).putExtra("mode", mode)); }
}
