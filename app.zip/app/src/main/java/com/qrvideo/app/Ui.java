package com.qrvideo.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

/** Small helpers so every screen is built the same way. */
final class Ui {
    static final int BG = 0xFF0F0A1F, TXT = 0xFFF5F3FF, SUB = 0xFFB4A7D6, LAV = 0xFFC4B5FD, DARK = 0xFF2E1065;
    private Ui() {}

    static int dp(Context c, int v) { return (int) (v * c.getResources().getDisplayMetrics().density + .5f); }

    /** Screen with a lavender title bar and a scrolling column. Returns the column. */
    static LinearLayout page(Activity a, String title) {
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(a);
        t.setText(title); t.setTextColor(DARK); t.setTextSize(18); t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER); t.setBackgroundColor(LAV);
        t.setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 14));
        root.addView(t, new LinearLayout.LayoutParams(-1, -2));
        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(a, 16), dp(a, 12), dp(a, 16), dp(a, 24));
        sv.addView(col, new ViewGroup.LayoutParams(-1, -2));
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        a.setContentView(root);
        return col;
    }

    static TextView text(Context c, String s, int sp, int color) {
        TextView t = new TextView(c);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(c, 8);
        t.setLayoutParams(p);
        return t;
    }

    static Button btn(Context c, String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(label); b.setAllCaps(false); b.setTextSize(15); b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(primary ? DARK : TXT);
        b.setBackgroundResource(primary ? R.drawable.bg_primary : R.drawable.bg_btn);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(c, 52));
        p.topMargin = dp(c, 10);
        b.setLayoutParams(p);
        return b;
    }

    static LinearLayout row(Context c, View... views) {
        LinearLayout r = new LinearLayout(c);
        for (View v : views) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(c, 52), 1f);
            p.topMargin = dp(c, 10); p.setMarginStart(dp(c, 4)); p.setMarginEnd(dp(c, 4));
            r.addView(v, p);
        }
        return r;
    }

    static LinearLayout card(Context c, String title, String sub, View.OnClickListener l) {
        LinearLayout k = new LinearLayout(c);
        k.setOrientation(LinearLayout.VERTICAL);
        k.setBackgroundResource(R.drawable.bg_card);
        k.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 18));
        k.setClickable(true);
        k.setOnClickListener(l);
        TextView t = text(c, title, 19, TXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        k.addView(t);
        if (!sub.isEmpty()) k.addView(text(c, sub, 13, SUB));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(c, 12);
        k.setLayoutParams(p);
        return k;
    }

    static void toast(Context c, String s) { Toast.makeText(c, s, Toast.LENGTH_SHORT).show(); }

    static void copy(Context c, String s) {
        ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("qr", s));
        toast(c, "Copied");
    }

    static void buzz(Context c) {
        Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null) return;
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE));
        else v.vibrate(60);
    }

    static boolean isUrl(String s) { return s != null && s.trim().matches("(?i)^(https?://|www\\.)\\S+$"); }
    static String url(String s) { s = s.trim(); return s.toLowerCase().startsWith("www.") ? "https://" + s : s; }
    static boolean isVideo(String s) {
        if (!isUrl(s)) return false;
        String p = Uri.parse(url(s)).getPath();
        return p != null && p.toLowerCase().matches(".*\\.(mp4|webm|m4v|3gp|mkv|mov)$");
    }

    /** Always shows the real host first, so a scanned link is never opened blindly. */
    static void openLink(final Activity a, String s) {
        final String u = url(s);
        String host = Uri.parse(u).getHost();
        new AlertDialog.Builder(a).setTitle("Open link?")
            .setMessage(host == null ? u : host + "\n\n" + u)
            .setPositiveButton("Open", (d, w) -> {
                try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); }
                catch (Exception e) { toast(a, "No app to open"); }
            })
            .setNegativeButton("Cancel", null).show();
    }
}
