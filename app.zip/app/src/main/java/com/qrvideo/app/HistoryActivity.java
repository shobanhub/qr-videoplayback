package com.qrvideo.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

/** Workflow 3: past scans, each with follow-up actions. */
public class HistoryActivity extends AppCompatActivity {
    private LinearLayout col;
    private String mode;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        mode = getIntent().getStringExtra("mode");
        col = Ui.page(this, "History");
        render();
    }

    private void render() {
        col.removeAllViews();
        List<String> h = Store.history(this);
        if (h.isEmpty()) { col.addView(Ui.text(this, "Empty", 15, Ui.SUB)); return; }
        for (final String t : h)
            col.addView(Ui.card(this, t.length() > 60 ? t.substring(0, 60) + "…" : t, "", v -> actions(t)));
        col.addView(Ui.btn(this, "Clear history", false, v -> { Store.clear(this); render(); }));
    }

    private void actions(final String t) {
        final List<String> items = new ArrayList<>();
        items.add("Copy");
        if (Ui.isVideo(t)) items.add("Play video");
        if (Ui.isUrl(t)) items.add("Open link");
        items.add("Make QR");
        new AlertDialog.Builder(this).setItems(items.toArray(new String[0]), (d, i) -> {
            String s = items.get(i);
            if (s.equals("Copy")) Ui.copy(this, t);
            else if (s.equals("Play video")) startActivity(new Intent(this, PlayerActivity.class).putExtra("mode", mode).putExtra("url", Ui.url(t)));
            else if (s.equals("Open link")) Ui.openLink(this, t);
            else startActivity(new Intent(this, GeneratorActivity.class).putExtra("mode", mode).putExtra("text", t));
        }).show();
    }
}
