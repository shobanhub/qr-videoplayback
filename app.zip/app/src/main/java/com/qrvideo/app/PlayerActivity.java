package com.qrvideo.app;

import android.net.Uri;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.VideoView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

/** Workflow 2: play a video from the phone or from a link. */
public class PlayerActivity extends AppCompatActivity {
    private static final String SAMPLE = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
    private VideoView video;
    private CheckBox loop;
    private final ActivityResultLauncher<String[]> pick = registerForActivityResult(
        new ActivityResultContracts.OpenDocument(), this::play);

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout col = Ui.page(this, "Video");
        video = new VideoView(this);
        col.addView(video, new LinearLayout.LayoutParams(-1, Ui.dp(this, 240)));
        MediaController mc = new MediaController(this);
        mc.setAnchorView(video);
        video.setMediaController(mc);
        video.setOnErrorListener((m, what, extra) -> { Ui.toast(this, "Can't play this video"); return true; });
        video.setOnPreparedListener(m -> { m.setLooping(loop.isChecked()); video.start(); });

        col.addView(Ui.btn(this, "Choose video", true, v -> pick.launch(new String[]{"video/*"})));
        col.addView(Ui.btn(this, "Sample", false, v -> play(Uri.parse(SAMPLE))));
        loop = new CheckBox(this);
        loop.setText("Loop");
        loop.setTextColor(Ui.TXT);
        col.addView(loop);

        String u = getIntent().getStringExtra("url");
        if (u != null) play(Uri.parse(u));
    }

    private void play(Uri uri) {
        if (uri != null) video.setVideoURI(uri);
    }
}
