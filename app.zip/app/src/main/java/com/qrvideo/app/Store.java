package com.qrvideo.app;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;

/** Scan history kept on the device only. */
final class Store {
    private static final String P = "qrvideo", K = "history";
    private Store() {}

    static List<String> history(Context c) {
        List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(P, 0).getString(K, "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.getString(i));
        } catch (Exception ignored) { }
        return out;
    }

    static void add(Context c, String text) {
        List<String> h = history(c);
        h.remove(text);
        h.add(0, text);
        while (h.size() > 50) h.remove(h.size() - 1);
        c.getSharedPreferences(P, 0).edit().putString(K, new JSONArray(h).toString()).apply();
    }

    static void clear(Context c) { c.getSharedPreferences(P, 0).edit().remove(K).apply(); }
}
