package com.qrvideo.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

/** Workflow menu. Viewer: Scan + Video. Generator: everything. */
public class HomeActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        final String mode = getIntent().getStringExtra("mode");
        boolean gen = "generator".equals(mode);
        LinearLayout col = Ui.page(this, gen ? "QR Generator" : "QR Viewer");
        col.addView(Ui.card(this, "Scan", "Read a QR code", v -> open(ScannerActivity.class, mode)));
        col.addView(Ui.card(this, "Video", "Play a video", v -> open(PlayerActivity.class, mode)));
        if (gen) {
            col.addView(Ui.card(this, "History", "Past scans", v -> open(HistoryActivity.class, mode)));
            col.addView(Ui.card(this, "Make QR", "Create a code", v -> open(GeneratorActivity.class, mode)));
        }
    }

    private void open(Class<?> c, String mode) { startActivity(new Intent(this, c).putExtra("mode", mode)); }
}
